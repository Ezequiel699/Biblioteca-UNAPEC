namespace BibliotecaAPEC.DTOs;
public class CreateUsuarioDto { public string Nombre { get; set; } = null!; public string Matricula { get; set; } = null!; }
