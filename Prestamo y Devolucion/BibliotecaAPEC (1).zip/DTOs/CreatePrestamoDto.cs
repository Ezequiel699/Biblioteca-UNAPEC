namespace BibliotecaAPEC.DTOs;
public class CreatePrestamoDto { public int UsuarioId { get; set; } public int LibroId { get; set; } }
